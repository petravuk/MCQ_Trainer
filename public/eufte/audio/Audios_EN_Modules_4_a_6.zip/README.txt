English revision audio — Regulation 2023/2841

Module 1: Understanding the Regulation — 5:26
Module 2: Obligations of Union entities — 6:32
Module 3: The IICB and compliance — 5:24
Module 4: CERT-EU services and cooperation — 6:13
Module 5: Incident reporting and crisis management — 6:01
Module 6: Deadlines and written communication — 4:04

Voice: Piper en_GB cori high, UK English female.
Training data: public-domain LibriVox recordings, https://librivox.org
Voice training information: https://brycebeattie.com/files/tts/
Questions include six-second pauses. Refer to the revision sheets for legal references.
